window.blackblock = {
  baseWidth: 800,
  baseHeight: 600,
  scale: 1
}
